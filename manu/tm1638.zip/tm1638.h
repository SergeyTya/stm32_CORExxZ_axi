#ifndef _TM1638_
#define _TM1638_

#include "commontypes.h"

namespace tm1638
{
	void init(bool activateDisplay = true, uchar intensity = 7);
	
	void setupDisplay(bool active, char intensity);

	void LEDOn(uint);
    void LEDInverse(uint);
    void LEDOff(uint);
	void allLEDOff();
	
	void setChar(int, char);
	
	void pointOn(int);
    void pointInverse(int);
	void pointOff(int);

    uint getKeys();
    
	void onTick();
};

#endif // #ifndef _TM1638_

