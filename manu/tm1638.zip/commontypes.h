#ifndef _COMMONTYPES_
#define _COMMONTYPES_

#include <stdint.h>

#include "inc\stm32f10x.h"
#include "inc\stm32f10x_conf.h"

typedef unsigned int uint;
typedef unsigned short ushort;
typedef unsigned char uchar;

#define ASSERT_FAIL(expr)

void inline Soft_Delay(volatile uint32_t number)
{
    while(number--);
};

#endif //#ifndef _COMMONTYPES_
