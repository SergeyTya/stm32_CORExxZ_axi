STM32_LCD_I2C
=============

This project about connect STM32F103 and LCD 2004 HD44780 through I2C(2Wire). Look this http://habrahabr.ru/post/223947/.

